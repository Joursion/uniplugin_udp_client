# udp-client

## 介绍

一个简单的支持安卓平台的，广播和接收 `udp` 数据的插件。

## 使用场景

服务端知道设备的 IP 之后，可以给设备发送消息，同时设备也可以给服务端发送消息

## Demo

```javascript
const udpClient = uni.requireNativePlugin('udp-client');
export default {
  data: function() {
    return {
      socketPort: 10005,
    }
  },
  onLoad() {
    /**
     * 在设备初始化，监听 10005 端口。
     * 假设本设备 IP 为 192.168.2.35
     * 那么服务端，或者其设备，就可以给 192.168.2.35:10005 发送消息了
     */
    udpClient.init(this.socketPort, this.onSocketMsg, this.onSocketError);
  },
  methods: {
    onSocketMsg(data) {
      console.log("接收到消息: " + data);
      // 收到消息如果想响应
      udpClient.send({
        ...data,
        data: JSON.stringify({code: 1, msg: "我收到消息啦～"}),
      });
    },
    onSocketError(errMsg) {
      console.error("socket 异常：" + errMsg);
    },
  },
  onUnload() {
    // 释放 socket，释放端口
    udpClient.release();
  }
}
```

## 使用文档

### 引入

```javascript
// #ifdef APP-PLUS
const client = uni.requireNativePlugin('udp-client');
// #endif
```

### 初始化

```javascript
/**
 * 初始化
 * @param listenPort 监听的端口
 * @param (res) => {} 返回消息 res: {host: string, port: number, data: string}
 * @param (errMsg) => {} 异常消息
 */
client.init(listenPort, (res) => {
  
}, (errMsg) => {

});
```

### 发送消息

```javascript
/**
 * 发送消息
 */
client.send({
  data: String,
  port: number,
  host: String, // 可选，不传默认为广播 255.255.255.255
});
```

### 释放

```javascript
/**
 * 释放，拿到数据之后手动释放，不然会占用资源
 */
client.release();
```

### 设置是否打印日志

```javascript
client.setIsDebug(false);
```
